// @refresh reset
/**
 * Read hooks for the TMS operations flow. Every number shown on screen comes
 * from these queries (loads, trucks, timeline, pending AI decisions).
 */

import { useInfiniteQuery, useQuery, useQueryClient } from "@tanstack/react-query";

import {
  fetchAllLoads,
  fetchAllTrucks,
  fetchDispatchRiskLoadsPage,
  fetchDispatchUnassignedLoadsPage,
  fetchLoad,
  fetchLoadAiStatuses,
  fetchLoadsPage,
  fetchLoadTimeline,
  fetchPendingSuggestions,
  TmsApiError,
  tmsKeys,
} from "@/api/tms-flow/tmsFlow.api";
import { TMS_LOAD_PAGE_SIZE } from "@/constants/tms";
import { useCurrentTenant } from "@/hooks/useCurrentTenant";
import type { PagedResponse } from "@/types/api.types";
import type { LoadResponse } from "@/types/load.dto";
import type {
  TmsLoadCollection,
  TmsLoadRiskReason,
  TmsShipmentView,
} from "@/types/tms-flow/tmsFlow.types";
import { sortTmsQueue, toTmsRiskShipment, toTmsShipment } from "@/utils/tms-flow/status";

const REFRESH_MS = 30_000;
const DISPATCH_BOARD_PAGE_SIZE = 20;

const isEndpointNotFoundError = (error: unknown): boolean =>
  error instanceof TmsApiError && error.status === 404;

const deriveClientFallbackRiskReasons = (
  load: LoadResponse,
  now: number,
): TmsLoadRiskReason[] => {
  const reasons: TmsLoadRiskReason[] = [];
  if (
    load.requestedPickupDate &&
    !load.pickedUpAt &&
    !load.deliveredAt &&
    Date.parse(load.requestedPickupDate) < now
  ) {
    reasons.push({
      code: "PICKUP_OVERDUE",
      message: "Pickup deadline has passed without pickup recorded.",
      dueAt: load.requestedPickupDate,
    });
  }
  if (
    load.requestedDeliveryDate &&
    !load.deliveredAt &&
    Date.parse(load.requestedDeliveryDate) < now
  ) {
    reasons.push({
      code: "DELIVERY_OVERDUE",
      message: "Requested delivery deadline has passed without delivery recorded.",
      dueAt: load.requestedDeliveryDate,
    });
  }
  return reasons;
};

export interface TmsLoadsSnapshot {
  collection: TmsLoadCollection;
  shipments: TmsShipmentView[];
  /** Single clock reading so every risk badge in one render uses the same `now`. */
  generatedAt: number;
}

export interface TmsLoadsPageSnapshot {
  page: PagedResponse<LoadResponse>;
  shipments: TmsShipmentView[];
  generatedAt: number;
  /** True only when a fallback count is derived from a capped collection. */
  countIsLowerBound?: boolean;
}

export interface TmsQueryOptions {
  /** Lets a caller skip the request until it knows the user may read the resource. */
  enabled?: boolean;
}

export interface TmsInfiniteQueryOptions extends TmsQueryOptions {
  pageSize?: number;
}

export function useInfiniteTmsLoads(options: TmsInfiniteQueryOptions = {}) {
  const { tenant } = useCurrentTenant();
  const pageSize = Math.max(1, Math.trunc(options.pageSize ?? TMS_LOAD_PAGE_SIZE));
  return useInfiniteQuery<TmsLoadsPageSnapshot>({
    queryKey: tmsKeys.infiniteLoads(tenant?.tenantKey, pageSize),
    queryFn: async ({ pageParam }) => {
      const pageNumber = Number(pageParam ?? 1);
      const page = await fetchLoadsPage(pageNumber, pageSize);
      const generatedAt = Date.now();
      return {
        page,
        generatedAt,
        shipments: page.items.map((load) => toTmsShipment(load, generatedAt)),
      };
    },
    getNextPageParam: (lastPage, allPages) => {
      const current = lastPage.page.currentPage || allPages.length;
      if (lastPage.page.items.length < pageSize) return undefined;
      if (lastPage.page.totalPages > 0) {
        return current < lastPage.page.totalPages ? current + 1 : undefined;
      }
      if (lastPage.page.totalItems > current * pageSize) {
        return current + 1;
      }
      return undefined;
    },
    enabled: options.enabled ?? true,
    staleTime: REFRESH_MS,
    refetchOnMount: "always",
    refetchInterval: REFRESH_MS,
    refetchIntervalInBackground: false,
    refetchOnWindowFocus: "always",
    retry: false,
  });
}

export function useInfiniteTmsRiskLoads(options: TmsInfiniteQueryOptions = {}) {
  const { tenant } = useCurrentTenant();
  const queryClient = useQueryClient();
  const pageSize = Math.max(
    1,
    Math.min(50, Math.trunc(options.pageSize ?? DISPATCH_BOARD_PAGE_SIZE)),
  );
  return useInfiniteQuery<TmsLoadsPageSnapshot>({
    queryKey: tmsKeys.infiniteRiskLoads(tenant?.tenantKey, pageSize),
    queryFn: async ({ pageParam }) => {
      const pageNumber = Number(pageParam ?? 1);
      try {
        const riskPage = await fetchDispatchRiskLoadsPage(pageNumber, pageSize);
        const generatedAt = Date.now();
        return {
          page: {
            ...riskPage,
            items: riskPage.items.map((item) => item.load),
          },
          generatedAt,
          shipments: riskPage.items.map((item) =>
            toTmsRiskShipment(item, generatedAt),
          ),
        };
      } catch (error) {
        if (!isEndpointNotFoundError(error)) {
          throw error;
        }
        const collection = await queryClient.fetchQuery({
          queryKey: ["tms", tenant?.tenantKey ?? "anonymous", "loads", "fallback-all"],
          queryFn: fetchAllLoads,
          staleTime: REFRESH_MS,
        });
        const generatedAt = Date.now();
        const allRiskShipments = sortTmsQueue(
          collection.items
            .map((load) => {
              const reasons = deriveClientFallbackRiskReasons(load, generatedAt);
              return toTmsShipment(load, generatedAt, undefined, reasons);
            })
            .filter(
              (shipment) =>
                shipment.status !== "cancelled" &&
                shipment.status !== "delivered" &&
                (shipment.risk !== "none" ||
                  (shipment.riskReasons?.length ?? 0) > 0),
            ),
        );
        const start = (pageNumber - 1) * pageSize;
        const slice = allRiskShipments.slice(start, start + pageSize);
        const totalItems = allRiskShipments.length;
        const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
        return {
          page: {
            items: slice.map((item) => item.raw),
            totalItems,
            totalPages,
            currentPage: pageNumber,
            pageSize,
          },
          generatedAt,
          shipments: slice,
          countIsLowerBound: collection.truncated,
        };
      }
    },
    getNextPageParam: (lastPage, allPages) => {
      const current = lastPage.page.currentPage || allPages.length;
      if (lastPage.page.items.length < pageSize) return undefined;
      if (lastPage.page.totalPages > 0) {
        return current < lastPage.page.totalPages ? current + 1 : undefined;
      }
      if (lastPage.page.totalItems > current * pageSize) {
        return current + 1;
      }
      return undefined;
    },
    enabled: options.enabled ?? true,
    staleTime: REFRESH_MS,
    refetchOnMount: "always",
    refetchInterval: REFRESH_MS,
    refetchIntervalInBackground: false,
    refetchOnWindowFocus: "always",
    retry: false,
  });
}

export function useInfiniteTmsUnassignedLoads(
  options: TmsInfiniteQueryOptions = {},
) {
  const { tenant } = useCurrentTenant();
  const queryClient = useQueryClient();
  const pageSize = Math.max(
    1,
    Math.min(50, Math.trunc(options.pageSize ?? DISPATCH_BOARD_PAGE_SIZE)),
  );
  return useInfiniteQuery<TmsLoadsPageSnapshot>({
    queryKey: tmsKeys.infiniteUnassignedLoads(tenant?.tenantKey, pageSize),
    queryFn: async ({ pageParam }) => {
      const pageNumber = Number(pageParam ?? 1);
      try {
        const page = await fetchDispatchUnassignedLoadsPage(pageNumber, pageSize);
        const generatedAt = Date.now();
        return {
          page,
          generatedAt,
          shipments: page.items.map((load) => toTmsShipment(load, generatedAt)),
        };
      } catch (error) {
        if (!isEndpointNotFoundError(error)) {
          throw error;
        }
        const collection = await queryClient.fetchQuery({
          queryKey: ["tms", tenant?.tenantKey ?? "anonymous", "loads", "fallback-all"],
          queryFn: fetchAllLoads,
          staleTime: REFRESH_MS,
        });
        const generatedAt = Date.now();
        const allUnassignedShipments = sortTmsQueue(
          collection.items
            .filter((load) => !load.assignedTruckId && !load.cancelledAt && load.status !== "CANCELLED")
            .map((load) => toTmsShipment(load, generatedAt))
            .filter(
              (shipment) =>
                shipment.status !== "cancelled" &&
                shipment.status !== "delivered",
            ),
        );
        const start = (pageNumber - 1) * pageSize;
        const slice = allUnassignedShipments.slice(start, start + pageSize);
        const totalItems = allUnassignedShipments.length;
        const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
        return {
          page: {
            items: slice.map((item) => item.raw),
            totalItems,
            totalPages,
            currentPage: pageNumber,
            pageSize,
          },
          generatedAt,
          shipments: slice,
          countIsLowerBound: collection.truncated,
        };
      }
    },
    getNextPageParam: (lastPage, allPages) => {
      const current = lastPage.page.currentPage || allPages.length;
      if (lastPage.page.items.length < pageSize) return undefined;
      if (lastPage.page.totalPages > 0) {
        return current < lastPage.page.totalPages ? current + 1 : undefined;
      }
      if (lastPage.page.totalItems > current * pageSize) {
        return current + 1;
      }
      return undefined;
    },
    enabled: options.enabled ?? true,
    staleTime: REFRESH_MS,
    refetchOnMount: "always",
    refetchInterval: REFRESH_MS,
    refetchIntervalInBackground: false,
    refetchOnWindowFocus: "always",
    retry: false,
  });
}

export function useTmsLoads(options: TmsQueryOptions = {}) {
  const { tenant } = useCurrentTenant();
  return useQuery<TmsLoadsSnapshot>({
    queryKey: tmsKeys.loads(tenant?.tenantKey),
    queryFn: async () => {
      const collection = await fetchAllLoads();
      const generatedAt = Date.now();
      return {
        collection,
        generatedAt,
        shipments: collection.items.map((load) => toTmsShipment(load, generatedAt)),
      };
    },
    enabled: options.enabled ?? true,
    staleTime: REFRESH_MS,
    // Loads are the source of truth for the dispatch queue. Always refresh when
    // the screen mounts and keep an open queue current, including after a
    // previous dev-server mock response was cached by React Query.
    refetchOnMount: "always",
    refetchInterval: REFRESH_MS,
    refetchIntervalInBackground: false,
    refetchOnWindowFocus: "always",
    retry: false,
  });
}

export function useTmsTrucks(options: TmsQueryOptions = {}) {
  const { tenant } = useCurrentTenant();
  return useQuery({
    queryKey: tmsKeys.trucks(tenant?.tenantKey),
    queryFn: fetchAllTrucks,
    enabled: options.enabled ?? true,
    staleTime: REFRESH_MS,
    refetchInterval: REFRESH_MS,
    refetchIntervalInBackground: false,
    refetchOnWindowFocus: "always",
    refetchOnMount: "always",
    retry: false,
  });
}

export function usePendingSuggestions() {
  const { tenant } = useCurrentTenant();
  return useQuery({
    queryKey: tmsKeys.pending(tenant?.tenantKey),
    queryFn: fetchPendingSuggestions,
    staleTime: REFRESH_MS,
    refetchInterval: REFRESH_MS,
    refetchIntervalInBackground: false,
    refetchOnWindowFocus: "always",
    refetchOnMount: "always",
    retry: false,
  });
}

export function useLoadAiStatuses(loadIds: readonly string[]) {
  const { tenant } = useCurrentTenant();
  return useQuery({
    queryKey: tmsKeys.aiStatuses(tenant?.tenantKey, loadIds),
    queryFn: () => fetchLoadAiStatuses(loadIds),
    enabled: loadIds.length > 0,
    staleTime: REFRESH_MS,
    refetchInterval: REFRESH_MS,
    refetchIntervalInBackground: false,
    refetchOnWindowFocus: "always",
    refetchOnMount: "always",
    retry: false,
  });
}

export function useTmsLoad(loadId: string | undefined) {
  const { tenant } = useCurrentTenant();
  return useQuery<TmsShipmentView>({
    queryKey: tmsKeys.load(tenant?.tenantKey, loadId ?? ""),
    queryFn: async () => {
      const load = await fetchLoad(loadId as string);
      return toTmsShipment(load, Date.now());
    },
    enabled: Boolean(loadId),
    staleTime: REFRESH_MS,
    refetchInterval: REFRESH_MS,
    refetchIntervalInBackground: false,
    refetchOnWindowFocus: "always",
    refetchOnMount: "always",
    retry: false,
  });
}

export function useTmsTimeline(loadId: string | undefined) {
  const { tenant } = useCurrentTenant();
  return useQuery({
    queryKey: tmsKeys.timeline(tenant?.tenantKey, loadId ?? ""),
    queryFn: () => fetchLoadTimeline(loadId as string),
    enabled: Boolean(loadId),
    staleTime: REFRESH_MS,
    refetchInterval: REFRESH_MS,
    refetchIntervalInBackground: false,
    refetchOnWindowFocus: "always",
    refetchOnMount: "always",
    retry: false,
  });
}
