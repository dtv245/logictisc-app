import { Tag, Timeline } from "antd";

import type { TmsTimelineEvent } from "@/types/tms-flow/tmsFlow.types";
import { formatTmsDateTime } from "@/utils/tms-flow/presentation";

export interface TmsTimelineProps {
  events: readonly TmsTimelineEvent[];
  limit?: number;
  emptyLabel?: string;
}

const resolveTimelineColor = (
  eventType?: string | null,
  status?: string | null,
): string => {
  const token = `${eventType ?? ""} ${status ?? ""}`.toUpperCase();
  if (token.includes("DELIVER") || token.includes("COMPLETE")) return "green";
  if (
    token.includes("CANCEL") ||
    token.includes("EXCEPTION") ||
    token.includes("FAIL") ||
    token.includes("REJECT")
  ) {
    return "red";
  }
  if (
    token.includes("DELAY") ||
    token.includes("ARRIVE") ||
    token.includes("HOLD") ||
    token.includes("WARN")
  ) {
    return "orange";
  }
  if (
    token.includes("PICK") ||
    token.includes("TRANSIT") ||
    token.includes("EN_ROUTE") ||
    token.includes("DEPART")
  ) {
    return "cyan";
  }
  return "blue";
};

export function TmsTimeline({
  events,
  limit,
  emptyLabel = "Chưa có sự kiện vận hành nào được ghi nhận.",
}: TmsTimelineProps) {
  const visible = [...events]
    .sort(
      (left, right) =>
        new Date(right.occurredAt).getTime() - new Date(left.occurredAt).getTime(),
    )
    .slice(0, limit ?? events.length);

  if (visible.length === 0) {
    return <p className="tms-empty">{emptyLabel}</p>;
  }

  return (
    <div className="tms-timeline" data-testid="tms-timeline">
      <Timeline
        items={visible.map((event) => {
          const color = resolveTimelineColor(event.eventType, event.newStatus);
          const transitionText =
            event.previousStatus && event.newStatus
              ? `${event.previousStatus} → ${event.newStatus}`
              : event.newStatus ?? event.source ?? "Đã ghi nhận";

          return {
            key: event.id,
            color,
            children: (
              <div
                className="tms-timeline__item"
                data-testid={`timeline-event-${event.id}`}
              >
                <div className="tms-timeline__header">
                  <span className="tms-timeline__title">
                    <Tag bordered={false} color={color} className="tms-timeline__tag">
                      {event.eventType}
                    </Tag>
                    <span className="tms-timeline__transition">
                      {transitionText}
                    </span>
                  </span>
                  <time
                    className="tms-timeline__time"
                    dateTime={event.occurredAt}
                  >
                    {formatTmsDateTime(event.occurredAt)}
                  </time>
                </div>
                {event.note ? (
                  <p className="tms-timeline__note">{event.note}</p>
                ) : null}
              </div>
            ),
          };
        })}
      />
    </div>
  );
}
