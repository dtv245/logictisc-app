import { useCan } from "@refinedev/core";
import { Alert, Button, Input, Modal } from "antd";
import { useState } from "react";
import { useTranslation } from "react-i18next";

import {
  ApprovalAlreadyPendingError,
  PendingSuggestionChangedError,
  useAiDecisionActions,
} from "@/hooks/tms-flow/useAiDecisionActions";
import type { TmsAiSuggestion, TmsApproval } from "@/types/tms-flow/tmsFlow.types";
import {
  describeSuggestionMetrics,
  describeTmsError,
  formatTmsDistance,
} from "@/utils/tms-flow/presentation";

export interface ApproveSuggestionModalProps {
  approval: TmsApproval;
  open: boolean;
  onClose: () => void;
  onDecisionComplete?: (approval: TmsApproval) => void;
  onSuggestionChanged?: (suggestion: TmsAiSuggestion) => void;
}

const REASON_MIN_LENGTH = 3;
const REASON_MAX_LENGTH = 500;

export function ApproveSuggestionModal({
  approval,
  open,
  onClose,
  onDecisionComplete,
  onSuggestionChanged,
}: ApproveSuggestionModalProps) {
  const { t } = useTranslation();
  const actions = useAiDecisionActions();
  const access = useCan({
    resource: "ai-dispatch",
    action: "AI_DISPATCH_APPROVE",
  });
  const [notes, setNotes] = useState("");
  const [reason, setReason] = useState("");
  const [localError, setLocalError] = useState<string | null>(null);

  const { suggestion, load, truck } = approval;
  const evidenceUnavailable = [suggestion.status, approval.dispatchStatus]
    .some((value) => value?.toLowerCase() === "evidence_unavailable");
  const truckLabel = truck?.licensePlate ?? suggestion.truckNumber ?? truck?.number;
  const driverName = suggestion.driverName
    ?? ([approval.driver?.firstName, approval.driver?.lastName].filter(Boolean).join(" ") || undefined)
    ?? (truck?.mainDriverId === suggestion.driverId ? truck.mainDriverName ?? undefined : undefined);
  const hasDecisionEvidence = Boolean(load && truckLabel && driverName && suggestion.decisionId)
    && !evidenceUnavailable;
  const canDecide = Boolean(access.data?.can) && !actions.pending && hasDecisionEvidence;
  const metrics = describeSuggestionMetrics(suggestion.metrics);

  const handleApprove = async () => {
    if (!canDecide) return;
    setLocalError(null);
    actions.clearError();
    try {
      await actions.approveIfCurrent({ decisionId: suggestion.decisionId, notes, suggestion });
      onDecisionComplete?.(approval);
      onClose();
    } catch (error) {
      if (error instanceof PendingSuggestionChangedError) {
        setLocalError(t("tmsDispatch.approval.changed"));
        if (error.current) onSuggestionChanged?.(error.current);
        return;
      }
      if (error instanceof ApprovalAlreadyPendingError) return;
      setLocalError(describeTmsError(error));
    }
  };

  const handleReject = async () => {
    if (!canDecide) return;
    const trimmed = reason.trim();
    if (trimmed.length < REASON_MIN_LENGTH || trimmed.length > REASON_MAX_LENGTH) {
      setLocalError(
        `Rejection reason must be ${REASON_MIN_LENGTH}–${REASON_MAX_LENGTH} characters.`,
      );
      return;
    }
    setLocalError(null);
    actions.clearError();
    try {
      await actions.reject({ decisionId: suggestion.decisionId, reason: trimmed });
      onDecisionComplete?.(approval);
      onClose();
    } catch (error) {
      setLocalError(describeTmsError(error));
    }
  };

  const error = localError ?? actions.error?.message ?? null;

  return (
    <Modal
      destroyOnHidden
      footer={[
        <Button key="cancel" onClick={onClose} disabled={actions.pending}>
          {t("tmsDispatch.approval.cancel")}
        </Button>,
        <Button
          danger
          data-testid="suggestion-reject"
          disabled={!canDecide}
          key="reject"
          loading={actions.pending}
          onClick={() => void handleReject()}
        >
          {t("tmsDispatch.approval.reject")}
        </Button>,
        <Button
          data-testid="suggestion-approve"
          disabled={!canDecide}
          key="approve"
          loading={actions.pending}
          onClick={() => void handleApprove()}
          type="primary"
        >
          {t("tmsDispatch.approval.approve")}
        </Button>,
      ]}
      onCancel={onClose}
      open={open}
      title={t("tmsDispatch.approval.title", { number: load?.number ?? "" })}
      width={560}
    >
      <div className="tms-stack">
        {!hasDecisionEvidence ? (
          <Alert
            message={t("tmsDispatch.approval.evidenceUnavailable")}
            showIcon
            type="warning"
          />
        ) : (
          <Alert
            message={t("tmsDispatch.approval.consequence", {
              number: load?.number,
              truck: truckLabel,
              driver: driverName,
            })}
            showIcon
            type="info"
          />
        )}
        {error ? (
          <Alert
            description={
              !localError && actions.error?.code
                ? `Code: ${actions.error.code}`
                : undefined
            }
            message={error}
            role="alert"
            showIcon
            type="error"
          />
        ) : null}

        <dl className="tms-detail-list">
          <div>
            <dt>Lô hàng</dt>
            <dd>
              {load
                ? `#${load.number} · ${load.name}`
                : `Đề xuất ${suggestion.decisionId.slice(0, 8)} (lô hàng chưa có trong danh sách đã tải)`}
            </dd>
          </div>
          {load ? (
            <div>
              <dt>Tuyến</dt>
              <dd>
                {load.originCity} → {load.destinationCity}
              </dd>
            </div>
          ) : null}
          <div>
            <dt>Xe</dt>
            <dd>
              {suggestion.truckNumber ?? truck?.number ?? suggestion.truckId}
              {truck?.mainDriverName ? ` · ${truck.mainDriverName}` : ""}
            </dd>
          </div>
          <div>
            <dt>Tài xế</dt>
            <dd>{suggestion.driverName ?? suggestion.driverId}</dd>
          </div>
          <div>
            <dt>Xếp hạng / điểm</dt>
            <dd>
              {suggestion.rank == null ? "Chưa xếp hạng" : `Hạng #${suggestion.rank}`} · {suggestion.score == null
                ? "Chưa đủ dữ liệu đánh giá"
                : Number(suggestion.score).toFixed(1)} · {suggestion.confidence ?? "Cần xác minh"}
            </dd>
          </div>
          {load ? (
            <div>
            <dt>Quãng đường</dt>
              <dd>{formatTmsDistance(load.distance)}</dd>
            </div>
          ) : null}
        </dl>

        {metrics.length > 0 ? (
          <div className="tms-row">
            {metrics.map((metric) => (
              <span className="tms-kpi__hint" key={metric}>
                {metric}
              </span>
            ))}
          </div>
        ) : null}

        <p className="tms-muted">{suggestion.reasoning}</p>

        <label className="tms-field">
          <span>{t("tmsDispatch.approval.notes")}</span>
          <Input.TextArea
            maxLength={500}
            onChange={(event) => setNotes(event.target.value)}
            placeholder={t("tmsDispatch.approval.notesPlaceholder")}
            rows={2}
            value={notes}
          />
        </label>

        <label className="tms-field">
          <span>{t("tmsDispatch.approval.rejectReason")}</span>
          <Input.TextArea
            maxLength={REASON_MAX_LENGTH}
            onChange={(event) => setReason(event.target.value)}
            placeholder={t("tmsDispatch.approval.rejectReasonPlaceholder")}
            rows={2}
            value={reason}
          />
        </label>
      </div>
    </Modal>
  );
}
