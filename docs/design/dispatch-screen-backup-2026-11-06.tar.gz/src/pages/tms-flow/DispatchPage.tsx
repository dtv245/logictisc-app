import { Alert, Button, Checkbox, Input, Skeleton, Spin, Tooltip } from "antd";
import {
  ExternalLink,
  RefreshCw,
  Search,
  Sparkles,
} from "lucide-react";
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type UIEvent,
  type WheelEvent,
} from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useTranslation } from "react-i18next";

import { ApproveSuggestionModal } from "@/components/tms-flow/ApproveSuggestionModal";
import { ApproveSelectedSuggestionsModal } from "@/components/tms-flow/ApproveSelectedSuggestionsModal";
import { DispatchNextActionBanner } from "@/components/tms-flow/DispatchNextActionBanner";
import { DispatchWorkSummary } from "@/components/tms-flow/DispatchWorkSummary";
import { FlowPanel } from "@/components/tms-flow/FlowPanel";
import { LoadCreateModal } from "@/components/loads/LoadCreateModal";
import { ShipmentCard } from "@/components/tms-flow/ShipmentCard";
import { StatusTag } from "@/components/StatusTag";
import { TmsFlowMap } from "@/components/tms-flow/TmsFlowMap";
import { TmsTimeline } from "@/components/tms-flow/TmsTimeline";
import { routes } from "@/constants/routes";
import { useTmsTimeline } from "@/hooks/tms-flow/useTmsQueries";
import {
  selectMostUrgentDispatchShipment,
  useDispatchSelection,
} from "@/hooks/tms-flow/useDispatchSelection";
import { useShipmentNextAction } from "@/hooks/tms-flow/useShipmentNextAction";
import { useTmsWorkspace } from "@/hooks/tms-flow/useTmsWorkspace";
import { useRouteEstimate } from "@/hooks/useRouteEstimate";
import type {
  TmsApproval,
  TmsQueueCounts,
  TmsQueueFilter,
  TmsShipmentView,
} from "@/types/tms-flow/tmsFlow.types";
import { toNetworkVehicles, toShipmentMarkers, toShipmentRouteLine, toTruckMarkers } from "@/utils/tms-flow/map";
import {
  describeSuggestionMetrics,
  describeTmsError,
  formatTmsDateTime,
  formatTmsDistance,
  formatTmsMoney,
  formatTmsRiskReason,
  operationalStatusMeta,
  riskMeta,
} from "@/utils/tms-flow/presentation";
import {
  matchesTmsQuery,
  selectTmsCounts,
  selectTmsQueue,
} from "@/utils/tms-flow/status";

const FILTERS: Array<{
  value: TmsQueueFilter;
  label: string;
  countKey: keyof TmsQueueCounts;
}> = [
  { value: "all", label: "Tất cả", countKey: "all" },
  { value: "at-risk", label: "Có rủi ro", countKey: "atRisk" },
  { value: "unassigned", label: "Chưa phân công", countKey: "unassigned" },
  { value: "approvals", label: "Duyệt AI", countKey: "approvals" },
];

const parseFilter = (value: string | null): TmsQueueFilter =>
  value === "at-risk" || value === "unassigned" || value === "approvals"
    ? value
    : "all";

const decisionMetrics = (approval: TmsApproval) =>
  describeSuggestionMetrics(approval.suggestion.metrics);

const QUEUE_SCROLL_THRESHOLD_PX = 120;

export interface DispatchPageProps {
  /** `/tms/approvals` renders the same workspace locked to pending decisions. */
  approvalsOnly?: boolean;
}

export function DispatchPage({ approvalsOnly = false }: DispatchPageProps) {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [searchParams, setSearchParams] = useSearchParams();
  const workspace = useTmsWorkspace();
  const [reviewed, setReviewed] = useState<TmsApproval | null>(null);
  const [selectedDecisionIds, setSelectedDecisionIds] = useState<Set<string>>(
    () => new Set(),
  );
  const [bulkReviewOpen, setBulkReviewOpen] = useState(false);
  const [lastCompletedShipment, setLastCompletedShipment] =
    useState<TmsShipmentView | null>(null);

  const filter: TmsQueueFilter = approvalsOnly
    ? "approvals"
    : parseFilter(searchParams.get("filter"));
  const query = searchParams.get("q") ?? "";
  const shipmentParam = searchParams.get("shipment");
  const decisionParam = searchParams.get("decision");
  const loadParam = searchParams.get("load");

  const {
    approvals,
    approvalIds,
    approvalsError,
    collection,
    loads,
    pending,
    riskCollection,
    riskError,
    riskLoads,
    riskShipments,
    shipments,
    statuses,
    trucks,
    trucksError,
    unassignedCollection,
    unassignedError,
    unassignedLoads,
    unassignedShipments,
  } = workspace;
  const fallbackCounts = selectTmsCounts(shipments, approvals.length);
  const counts: TmsQueueCounts = {
    all: collection?.totalItems ?? fallbackCounts.all,
    atRisk: riskCollection?.totalItems ?? fallbackCounts.atRisk,
    unassigned: unassignedCollection?.totalItems ?? fallbackCounts.unassigned,
    approvals: approvals.length,
  };
  const queue =
    filter === "at-risk" && riskShipments !== undefined
      ? riskShipments.filter((shipment) => matchesTmsQuery(shipment, query))
      : filter === "unassigned" && unassignedShipments !== undefined
      ? unassignedShipments.filter((shipment) => matchesTmsQuery(shipment, query))
      : selectTmsQueue(shipments, filter, query, approvalIds);
  const defaultShipment = useMemo(
    () => selectMostUrgentDispatchShipment(queue),
    [queue],
  );
  const selection = useDispatchSelection({
    requestedId: approvalsOnly ? null : shipmentParam,
    visibleShipments: queue,
    knownShipments: workspace.allKnownShipments ?? [],
    defaultShipment,
    filter,
    query,
    approvalLoadIds: approvalIds,
  });
  const selected = selection.status === "selected" ? selection.shipment : undefined;

  const activeLoadsQuery =
    filter === "at-risk" && riskLoads
      ? riskLoads
      : filter === "unassigned" && unassignedLoads
      ? unassignedLoads
      : loads;
  const activeCollection =
    filter === "at-risk" && riskCollection !== undefined
      ? riskCollection
      : filter === "unassigned" && unassignedCollection !== undefined
      ? unassignedCollection
      : collection;

  const hasNextLoadsPage = Boolean(activeLoadsQuery.hasNextPage);
  const isFetchingNextLoadsPage = Boolean(activeLoadsQuery.isFetchingNextPage);
  const isLoadingMoreRef = useRef(false);

  const loadMoreShipments = useCallback(() => {
    if (
      !hasNextLoadsPage ||
      isFetchingNextLoadsPage ||
      isLoadingMoreRef.current ||
      typeof activeLoadsQuery.fetchNextPage !== "function"
    ) {
      return;
    }
    isLoadingMoreRef.current = true;
    Promise.resolve(activeLoadsQuery.fetchNextPage()).finally(() => {
      isLoadingMoreRef.current = false;
    });
  }, [activeLoadsQuery, hasNextLoadsPage, isFetchingNextLoadsPage]);

  const handleQueueScroll = useCallback(
    (event: UIEvent<HTMLDivElement>) => {
      const container = event.currentTarget;
      const remaining =
        container.scrollHeight - container.scrollTop - container.clientHeight;
      if (remaining <= QUEUE_SCROLL_THRESHOLD_PX) {
        loadMoreShipments();
      }
    },
    [loadMoreShipments],
  );

  const handleQueueWheel = useCallback(
    (event: WheelEvent<HTMLDivElement>) => {
      if (event.deltaY <= 0) return;
      const container = event.currentTarget;
      const remaining =
        container.scrollHeight - container.scrollTop - container.clientHeight;
      if (remaining <= QUEUE_SCROLL_THRESHOLD_PX) {
        loadMoreShipments();
      }
    },
    [loadMoreShipments],
  );

  // Explicit decision/load params never fall back to another pending decision:
  // doing so silently reviews the wrong load. Only the bare route picks the first.
  const selectedApproval = decisionParam
    ? approvals.find(
        (item) => item.suggestion.decisionId === decisionParam,
      )
    : loadParam
    ? approvals.find((item) => item.load?.id === loadParam)
    : approvals[0];
  const selectedDecision = approvalsOnly ? selectedApproval : undefined;
  const selectedApprovals = approvals.filter((approval) =>
    selectedDecisionIds.has(approval.suggestion.decisionId),
  );
  const selectedLoad = approvalsOnly ? selectedDecision?.load : selected;
  const shipmentRoute = useRouteEstimate(
    selectedLoad?.originLatitude != null && selectedLoad.originLongitude != null
      ? { latitude: selectedLoad.originLatitude, longitude: selectedLoad.originLongitude }
      : null,
    selectedLoad?.destinationLatitude != null && selectedLoad.destinationLongitude != null
      ? { latitude: selectedLoad.destinationLatitude, longitude: selectedLoad.destinationLongitude }
      : null,
    { includeGeometry: true },
  );
  const mapRoutes = toShipmentRouteLine(selectedLoad, shipmentRoute.estimate?.coordinates);
  const focusApprovals = selected
    ? approvals.filter((item) => item.load?.id === selected.id)
    : [];
  const nextAction = useShipmentNextAction({
    shipment: selected,
    approvals: focusApprovals,
  });
  const selectedTruck = workspace.trucks.data?.items.find(
    (truck) => truck.id === selectedLoad?.assignedTruckId,
  );

  const timeline = useTmsTimeline(selectedLoad?.id);
  const renderTimeline = (limit: number) =>
    timeline.isLoading ? (
      <Spin size="small" />
    ) : timeline.error ? (
      <Alert
        action={
          <Button
            icon={<RefreshCw size={14} aria-hidden="true" />}
            onClick={() => void timeline.refetch()}
            size="small"
          >
            Thử lại
          </Button>
        }
        description={describeTmsError(timeline.error)}
        message="Không tải được dòng thời gian vận hành"
        showIcon
        type="warning"
      />
    ) : (
      <TmsTimeline
        emptyLabel="Chưa có sự kiện vận hành cho lô hàng này."
        events={timeline.data?.events ?? []}
        limit={limit}
      />
    );
  const truckItems = trucks.data?.items ?? [];
  const locatedTrucks = truckItems
    .filter(
      (truck) =>
        truck.currentLocationLatitude != null &&
        truck.currentLocationLongitude != null,
    )
    .slice(0, 120);
  const markers = [
    ...toShipmentMarkers(selectedLoad),
    ...toTruckMarkers(locatedTrucks),
  ];

  const updateParam = useCallback(
    (key: string, value: string | undefined) => {
      const next = new URLSearchParams(searchParams);
      if (value) next.set(key, value);
      else next.delete(key);
      setSearchParams(next, { replace: true });
    },
    [searchParams, setSearchParams],
  );

  const setFilter = (value: TmsQueueFilter) => {
    const next = new URLSearchParams(searchParams);
    if (value === "all") next.delete("filter");
    else next.set("filter", value);
    setSearchParams(next, { replace: true });
  };

  useEffect(() => {
    if (approvalsOnly || shipmentParam || selection.status !== "selected") return;
    updateParam("shipment", selection.shipment.id);
  }, [approvalsOnly, selection, shipmentParam, updateParam]);

  const handleDecisionComplete = useCallback(
    (approval: TmsApproval) => {
      const completed = approval.load ?? selected;
      if (!completed) return;
      const actionableLoads = queue.filter(
        (shipment) =>
          shipment.id !== completed.id &&
          shipment.status !== "cancelled" &&
          shipment.status !== "delivered" &&
          (shipment.risk !== "none" ||
            (shipment.riskReasons?.length ?? 0) > 0 ||
            (!shipment.assignedTruckId && !shipment.assignedTruckNumber)),
      );
      const next = selectMostUrgentDispatchShipment(actionableLoads);
      if (!next) return;
      setLastCompletedShipment(completed);
      updateParam("shipment", next.id);
    },
    [queue, selected, updateParam],
  );

  if (workspace.isLoading) {
    return (
      <div className="tms-page tms-flow--centered" aria-busy="true">
        <Spin size="large" />
        <p className="tms-muted">Đang tải dữ liệu điều phối…</p>
      </div>
    );
  }

  if (workspace.error) {
    return (
      <div className="tms-page">
        <Alert
          action={
            <Button
              icon={<RefreshCw size={14} aria-hidden="true" />}
              onClick={() => {
                void workspace.loads.refetch();
                void workspace.riskLoads?.refetch();
                void workspace.unassignedLoads?.refetch();
                void workspace.pending.refetch();
                void workspace.trucks.refetch();
              }}
            >
              Thử lại
            </Button>
          }
          description={describeTmsError(workspace.error)}
          message="Không tải được dữ liệu điều phối"
          showIcon
          type="error"
        />
      </div>
    );
  }

  return (
    <div className="tms-page">
      <div className="tms-page__lead">
        <div className="tms-row">
          <LoadCreateModal
            onCreated={() => {
              void workspace.loads.refetch();
              void workspace.riskLoads?.refetch();
              void workspace.unassignedLoads?.refetch();
            }}
            trigger={(show) => (
              <Button onClick={show}>Tạo lô hàng</Button>
            )}
          />
          {approvalsOnly ? (
            <Button onClick={() => navigate(routes.tmsFlow.dispatch)}>Quay lại điều phối</Button>
          ) : null}
        </div>
        {workspace.updatedAt ? (
          <span className="tms-refresh-state" role="status">
            {workspace.isRefreshing ? <Spin size="small" aria-hidden="true" /> : null}
            {t("tmsDispatch.refresh.updatedAt", {
              time: new Intl.DateTimeFormat("vi-VN", {
                hour: "2-digit",
                minute: "2-digit",
              }).format(workspace.updatedAt),
            })}
          </span>
        ) : null}
      </div>

      {!approvalsOnly && workspace.refreshFailed ? (
        <Alert
          className="tms-refresh-warning"
          message={t("tmsDispatch.refresh.failed")}
          showIcon
          type="warning"
        />
      ) : null}

      {!approvalsOnly ? (
        <DispatchWorkSummary
          atRiskCount={riskCollection?.totalItems}
          atRiskIsLowerBound={riskCollection?.truncated}
          unassignedCount={unassignedCollection?.totalItems}
          unassignedIsLowerBound={unassignedCollection?.truncated}
          pendingApprovalCount={pending.data?.length}
          onAtRisk={() => setFilter("at-risk")}
          onPendingApprovals={() => navigate(routes.tmsFlow.approvals)}
          onUnassigned={() => setFilter("unassigned")}
        />
      ) : null}

      {approvalsError ? (
        <Alert
          action={
            <Button
              icon={<RefreshCw size={14} aria-hidden="true" />}
              onClick={() => {
                void pending.refetch();
                void statuses.refetch();
              }}
            >
              Thử lại
            </Button>
          }
          message="Không tải được đề xuất AI"
          description={`${describeTmsError(approvalsError)} Hàng đợi vẫn khả dụng; đề xuất chờ duyệt và trạng thái AI chưa được hiển thị.`}
          showIcon
          type="warning"
        />
      ) : null}

      {trucksError ? (
        <Alert
          action={
            <Button
              icon={<RefreshCw size={14} aria-hidden="true" />}
              onClick={() => void trucks.refetch()}
            >
              Thử lại
            </Button>
          }
          message="Không tải được vị trí xe"
          description={`${describeTmsError(trucksError)} Bản đồ tuyến chưa hiển thị xe cho đến khi có dữ liệu.`}
          showIcon
          type="warning"
        />
      ) : null}

      {!approvalsOnly && filter === "at-risk" && riskError ? (
        <Alert
          action={
            <Button
              icon={<RefreshCw size={14} aria-hidden="true" />}
              onClick={() => void riskLoads?.refetch()}
            >
              Thử lại
            </Button>
          }
          message="Không tải được danh sách lô hàng rủi ro"
          description={describeTmsError(riskError)}
          showIcon
          type="warning"
        />
      ) : null}

      {!approvalsOnly && filter === "unassigned" && unassignedError ? (
        <Alert
          action={
            <Button
              icon={<RefreshCw size={14} aria-hidden="true" />}
              onClick={() => void unassignedLoads?.refetch()}
            >
              Thử lại
            </Button>
          }
          message="Không tải được danh sách lô hàng chưa phân công"
          description={describeTmsError(unassignedError)}
          showIcon
          type="warning"
        />
      ) : null}

      {!approvalsOnly && selection.status === "loading" ? (
        <Alert
          message={t("tmsDispatch.selection.loading", { defaultValue: "Đang tìm lô hàng này…" })}
          showIcon
          type="info"
        />
      ) : null}
      {!approvalsOnly && selection.status === "not-found" ? (
        <Alert
          message={t("tmsDispatch.selection.notFound", { defaultValue: "Không tìm thấy lô này. Có thể lô đã bị xóa hoặc bạn không có quyền xem." })}
          showIcon
          type="warning"
        />
      ) : null}
      {!approvalsOnly && selection.status === "hidden" ? (
        <Alert
          action={(
            <Button
              onClick={() => {
                const next = new URLSearchParams(searchParams);
                next.delete("filter");
                next.delete("q");
                setSearchParams(next, { replace: true });
              }}
              size="small"
            >
              {t("tmsDispatch.selection.clearFilters", { defaultValue: "Bỏ lọc để xem" })}
            </Button>
          )}
          message={t("tmsDispatch.selection.hidden", { defaultValue: "Lô này đang bị ẩn do bộ lọc." })}
          showIcon
          type="info"
        />
      ) : null}
      {!approvalsOnly && selection.status === "error" ? (
        <Alert
          action={(
            <Button onClick={selection.retry} size="small">
              {t("tmsDispatch.selection.retry", { defaultValue: "Thử lại" })}
            </Button>
          )}
          description={describeTmsError(selection.error)}
          message={t("tmsDispatch.selection.error", { defaultValue: "Chưa tải được thông tin lô hàng này." })}
          showIcon
          type="error"
        />
      ) : null}
      {!approvalsOnly && selection.status === "selected" && selection.outsideQueue ? (
        <Alert
          message={t("tmsDispatch.selection.outsideQueue", { defaultValue: "Lô này đã mở nhưng chưa nằm trong phần danh sách hiện đang tải." })}
          showIcon
          type="info"
        />
      ) : null}

      {!approvalsOnly && selection.status === "selected" ? (
        <DispatchNextActionBanner
          action={nextAction}
          onReviewSuggestion={() => {
            if (nextAction.kind === "approve-suggestion") setReviewed(nextAction.approval);
          }}
          onViewLoad={() => {
            if (selected) navigate(`/tms/shipments/${selected.id}`);
          }}
        />
      ) : null}
      {!approvalsOnly && lastCompletedShipment && selected?.id !== lastCompletedShipment.id ? (
        <Button
          className="tms-control-button"
          onClick={() => {
            updateParam("shipment", lastCompletedShipment.id);
            setLastCompletedShipment(null);
          }}
        >
          {t("tmsDispatch.summary.returnToCompleted")}
        </Button>
      ) : null}

      {!approvalsOnly && activeCollection?.truncated ? (
        <Alert
          message={`Hàng đợi đang hiển thị ${activeCollection.items.length.toLocaleString("vi-VN")}/${activeCollection.totalItems.toLocaleString("vi-VN")} lô hàng đầu tiên`}
          description="Kéo xuống cuối danh sách để tải thêm các trang tiếp theo từ hệ thống."
          showIcon
          type="warning"
        />
      ) : null}

      <div className="tms-dispatch">
        <FlowPanel
          action={approvalsOnly ? (
            <Button
              disabled={selectedApprovals.length === 0}
              onClick={() => setBulkReviewOpen(true)}
              size="small"
              type="primary"
            >
              Duyệt {selectedApprovals.length} đề xuất
            </Button>
          ) : null}
          testId={approvalsOnly ? "approvals-list" : "dispatch-queue"}
          title={approvalsOnly ? "Đề xuất đang chờ duyệt" : "Hàng đợi điều phối"}
        >
          {approvalsOnly ? (
            <div className="tms-decision-list">
              {approvals.length > 0 ? (
                <div className="tms-decision-list__toolbar">
                  <Checkbox
                    checked={approvals.every((item) => selectedDecisionIds.has(item.suggestion.decisionId))}
                    indeterminate={selectedApprovals.length > 0 && selectedApprovals.length < approvals.length}
                    onChange={(event) => {
                      setSelectedDecisionIds((current) => {
                        const next = new Set(current);
                        approvals.forEach((item) => {
                          if (event.target.checked) next.add(item.suggestion.decisionId);
                          else next.delete(item.suggestion.decisionId);
                        });
                        return next;
                      });
                    }}
                  >
                    Chọn tất cả ({approvals.length})
                  </Checkbox>
                </div>
              ) : null}
              {approvals.map((approval) => {
                const isSelected =
                  approval.suggestion.decisionId ===
                  selectedDecision?.suggestion.decisionId;
                return (
                  <div
                    className={`tms-decision-row-wrap${isSelected ? " is-focused" : ""}`}
                    key={approval.suggestion.decisionId}
                  >
                    <Checkbox
                      aria-label={`Chọn đề xuất ${approval.load?.number ?? approval.suggestion.decisionId}`}
                      checked={selectedDecisionIds.has(approval.suggestion.decisionId)}
                      onChange={(event) => {
                        setSelectedDecisionIds((current) => {
                          const next = new Set(current);
                          if (event.target.checked) next.add(approval.suggestion.decisionId);
                          else next.delete(approval.suggestion.decisionId);
                          return next;
                        });
                      }}
                    />
                    <button
                      className={`tms-decision-row${isSelected ? " is-selected" : ""}`}
                      data-testid={`decision-row-${approval.suggestion.decisionId}`}
                      onClick={() => updateParam("decision", approval.suggestion.decisionId)}
                      type="button"
                    >
                    <span className="tms-decision-row__main">
                      <Tooltip
                        title={
                          approval.load
                            ? `#${approval.load.number} · ${approval.load.originCity} → ${approval.load.destinationCity}`
                            : `Đề xuất ${approval.suggestion.decisionId.slice(0, 8)}`
                        }
                      >
                        <strong className="table-cell-ellipsis">
                          {approval.load
                            ? `#${approval.load.number} · ${approval.load.originCity} → ${approval.load.destinationCity}`
                            : `Đề xuất ${approval.suggestion.decisionId.slice(0, 8)}`}
                        </strong>
                      </Tooltip>
                      <Tooltip
                        title={`${approval.suggestion.truckNumber ?? approval.suggestion.truckId}${approval.suggestion.driverName ? ` · ${approval.suggestion.driverName}` : ""}`}
                      >
                        <small className="tms-muted table-cell-ellipsis">
                          {approval.suggestion.truckNumber ?? approval.suggestion.truckId}
                          {approval.suggestion.driverName
                            ? ` · ${approval.suggestion.driverName}`
                            : ""}
                        </small>
                      </Tooltip>
                    </span>
                    <span className="tms-decision-row__meta">
                      <span>
                        {approval.suggestion.rank == null ? "Chưa xếp hạng" : `Hạng #${approval.suggestion.rank}`} ·{" "}
                        {approval.suggestion.score == null
                          ? "Chưa đánh giá"
                          : Number(approval.suggestion.score).toFixed(1)}
                      </span>
                      <span className="tms-muted">
                        {approval.suggestion.confidence ?? "Cần xác minh"}
                      </span>
                    </span>
                    </button>
                  </div>
                );
              })}
              {approvals.length === 0 ? (
                <p className="tms-empty">Không có đề xuất điều phối AI đang chờ duyệt.</p>
              ) : null}
            </div>
          ) : (
            <>
              <div className="tms-filters" role="group" aria-label="Queue filter">
                {FILTERS.map((item) => (
                  <button
                    aria-pressed={filter === item.value}
                    className={filter === item.value ? "is-active" : ""}
                    data-testid={`dispatch-filter-${item.value}`}
                    key={item.value}
                    onClick={() => setFilter(item.value)}
                    type="button"
                  >
                    {item.label} {counts[item.countKey]}
                  </button>
                ))}
              </div>
              <Input
                allowClear
                onChange={(event) => updateParam("q", event.target.value)}
                placeholder="Tìm mã lô, khách hàng, thành phố hoặc địa chỉ"
                prefix={<Search size={14} aria-hidden="true" />}
                value={query}
              />
              <div
                className="tms-queue"
                data-testid="dispatch-load-queue"
                onScroll={handleQueueScroll}
                onWheel={handleQueueWheel}
              >
                {queue.map((shipment) => (
                  <ShipmentCard
                    compact
                    key={shipment.id}
                    onSelect={() => updateParam("shipment", shipment.id)}
                    selected={selected?.id === shipment.id}
                    shipment={shipment}
                  />
                ))}
                {queue.length === 0 && !isFetchingNextLoadsPage ? (
                  <p className="tms-empty">Không có lô hàng phù hợp.</p>
                ) : null}
                {isFetchingNextLoadsPage ? (
                  <div
                    className="tms-queue__more"
                    data-testid="dispatch-queue-loading-more"
                  >
                    <Spin size="small" />
                    <span className="tms-muted">Đang tải thêm lô hàng…</span>
                  </div>
                ) : hasNextLoadsPage ? (
                  <button
                    className="tms-queue__more tms-queue__more--action"
                    data-testid="dispatch-queue-load-more"
                    onClick={loadMoreShipments}
                    type="button"
                  >
                    <span>
                      Đã tải {(activeCollection?.items.length ?? queue.length).toLocaleString("vi-VN")}
                      {activeCollection?.totalItems
                        ? `/${activeCollection.totalItems.toLocaleString("vi-VN")}`
                        : ""}{" "}
                      lô hàng · Kéo xuống để tải thêm
                    </span>
                  </button>
                ) : null}
              </div>
            </>
          )}
        </FlowPanel>

        <div className="tms-stack">
          <TmsFlowMap
            markers={markers}
            routes={mapRoutes}
            isRouteLoading={shipmentRoute.isLoading}
            isRouteError={shipmentRoute.isError}
            subtitle={
              selectedLoad
                ? `${selectedLoad.originCity} → ${selectedLoad.destinationCity}`
                : undefined
            }
            testId="dispatch-map"
                    title="Bản đồ tuyến ước tính"
            vehicles={toNetworkVehicles(locatedTrucks)}
          />

          {approvalsOnly ? (
            <FlowPanel
              action={
                selectedDecision?.load ? (
                  <Button
                    icon={<ExternalLink size={14} aria-hidden="true" />}
                    onClick={() =>
                      navigate(`/tms/shipments/${selectedDecision.load?.id ?? ""}`)
                    }
                  >
                    Mở lô hàng
                  </Button>
                ) : null
              }
              title="Chi tiết đề xuất"
            >
              {selectedDecision ? (
                <div className="tms-stack">
                  <div className="tms-row">
                    <StatusTag
                      label={selectedDecision.suggestion.confidence ?? "Cần xác minh"}
                      tone="neutral"
                    />
                    <span className="tms-muted">
                      {selectedDecision.suggestion.rank == null ? "Chưa xếp hạng" : `Hạng #${selectedDecision.suggestion.rank}`} · {selectedDecision.suggestion.score == null
                        ? "chưa có điểm đánh giá"
                        : `điểm ${Number(selectedDecision.suggestion.score).toFixed(1)}`}
                    </span>
                  </div>
                  <dl className="tms-detail-list">
                    <div>
                      <dt>Xe</dt>
                      <Tooltip
                        title={
                          selectedDecision.suggestion.truckNumber ??
                          selectedDecision.truck?.number ??
                          selectedDecision.suggestion.truckId
                        }
                      >
                        <dd className="table-cell-ellipsis">
                          {selectedDecision.suggestion.truckNumber ??
                            selectedDecision.truck?.number ??
                            selectedDecision.suggestion.truckId}
                        </dd>
                      </Tooltip>
                    </div>
                    <div>
                      <dt>Tài xế</dt>
                      <Tooltip
                        title={
                          selectedDecision.suggestion.driverName ??
                          selectedDecision.suggestion.driverId
                        }
                      >
                        <dd className="table-cell-ellipsis">
                          {selectedDecision.suggestion.driverName ??
                            selectedDecision.suggestion.driverId}
                        </dd>
                      </Tooltip>
                    </div>
                    {selectedDecision.load ? (
                      <div>
                        <dt>Khách hàng</dt>
                        <Tooltip title={selectedDecision.load.customerName}>
                          <dd className="table-cell-ellipsis">{selectedDecision.load.customerName}</dd>
                        </Tooltip>
                      </div>
                    ) : null}
                    {selectedDecision.load ? (
                      <div>
                        <dt>Giờ giao yêu cầu</dt>
                        <dd>
                          {formatTmsDateTime(
                            selectedDecision.load.requestedDeliveryDate,
                          )}
                        </dd>
                      </div>
                    ) : null}
                    {decisionMetrics(selectedDecision).map((metric) => (
                      <div key={metric}>
                    <dt>Chỉ số</dt>
                        <Tooltip title={metric}>
                          <dd className="table-cell-ellipsis">{metric}</dd>
                        </Tooltip>
                      </div>
                    ))}
                  </dl>
                  <Tooltip title={selectedDecision.suggestion.reasoning}>
                    <p className="tms-muted">{selectedDecision.suggestion.reasoning}</p>
                  </Tooltip>
                  <div className="tms-row">
                    <Button
                      onClick={() => setReviewed(selectedDecision)}
                      type="primary"
                    >
                      Xem và quyết định
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="tms-empty">
                  {decisionParam || loadParam
                    ? "Đề xuất được yêu cầu không còn trong hàng đợi chờ duyệt."
                    : "Chọn một đề xuất đang chờ duyệt."}
                </p>
              )}
            </FlowPanel>
          ) : (
            <FlowPanel
              action={
                selected ? (
                  <Button
                    icon={<ExternalLink size={14} aria-hidden="true" />}
                    onClick={() => navigate(`/tms/shipments/${selected.id}`)}
                  >
                    Mở lô hàng
                  </Button>
                ) : null
              }
              title="Lô hàng đang chọn"
            >
              {selected ? (
                <dl className="tms-detail-list">
                  <div>
                    <dt>Lô hàng</dt>
                    <Tooltip title={`#${selected.number} · ${selected.name}`}>
                      <dd className="table-cell-ellipsis">
                        #{selected.number} · {selected.name}
                      </dd>
                    </Tooltip>
                  </div>
                  <div>
                    <dt>Khách hàng</dt>
                    <Tooltip title={selected.customerName}>
                      <dd className="table-cell-ellipsis">{selected.customerName}</dd>
                    </Tooltip>
                  </div>
                  <div>
                    <dt>Tuyến</dt>
                    <Tooltip title={`${selected.originCity} → ${selected.destinationCity}`}>
                      <dd className="table-cell-ellipsis">
                        {selected.originCity} → {selected.destinationCity}
                      </dd>
                    </Tooltip>
                  </div>
                  <div>
                    <dt>Giờ lấy hàng yêu cầu</dt>
                    <dd>{formatTmsDateTime(selected.requestedPickupDate)}</dd>
                  </div>
                  <div>
                    <dt>Giờ giao yêu cầu</dt>
                    <dd>{formatTmsDateTime(selected.requestedDeliveryDate)}</dd>
                  </div>
                  <div>
                    <dt>Trạng thái</dt>
                    <dd>
                      <StatusTag
                        label={operationalStatusMeta[selected.status].label}
                        tone={operationalStatusMeta[selected.status].tone}
                      />
                      {selected.risk !== "none" ? (
                        <StatusTag
                          label={riskMeta[selected.risk].label}
                          tone={riskMeta[selected.risk].tone}
                        />
                      ) : null}
                    </dd>
                  </div>
                  {selected.riskReasons && selected.riskReasons.length > 0 ? (
                    <div data-testid="selected-load-risk-reasons">
                      <dt>Lý do rủi ro</dt>
                      <Tooltip
                        title={selected.riskReasons.map(formatTmsRiskReason).join(" · ")}
                      >
                        <dd className="table-cell-ellipsis">
                          {selected.riskReasons.map(formatTmsRiskReason).join(" · ")}
                        </dd>
                      </Tooltip>
                    </div>
                  ) : null}
                  <div>
                    <dt>Xe</dt>
                    <Tooltip
                      title={
                        selected.assignedTruckNumber ??
                        selectedTruck?.number ??
                        "Chưa phân công"
                      }
                    >
                      <dd className="table-cell-ellipsis">
                        {selected.assignedTruckNumber ??
                          selectedTruck?.number ??
                          "Chưa phân công"}
                      </dd>
                    </Tooltip>
                  </div>
                  <div>
                    <dt>Tài xế</dt>
                    <Tooltip title={selectedTruck?.mainDriverName ?? "Chưa phân công"}>
                      <dd className="table-cell-ellipsis">
                        {selectedTruck?.mainDriverName ?? "Chưa phân công"}
                      </dd>
                    </Tooltip>
                  </div>
                  <div>
                    <dt>Quãng đường</dt>
                    <dd>{formatTmsDistance(selected.distance)}</dd>
                  </div>
                  <div>
                    <dt>Cước vận chuyển</dt>
                    <dd>
                      {formatTmsMoney(
                        selected.deliveryCostAmount,
                        selected.deliveryCostCurrency,
                      )}
                    </dd>
                  </div>
                </dl>
              ) : selection.status === "loading" ? (
                <Skeleton active paragraph={{ rows: 5 }} />
              ) : (
                <p className="tms-empty">Chọn một lô hàng trong hàng đợi.</p>
              )}
            </FlowPanel>
          )}
        </div>

        <div className="tms-stack tms-dispatch__agent">
          {approvalsOnly ? (
            <FlowPanel title="Dòng thời gian vận hành">
              {renderTimeline(8)}
            </FlowPanel>
          ) : (
            <FlowPanel
              subtitle={selected ? `Load #${selected.number}` : undefined}
              title="Trợ lý điều phối AI"
            >
              {focusApprovals.length === 0 ? (
                <div className="tms-stack">
                  <p className="tms-empty">
                    Lô hàng này không có đề xuất AI đang chờ duyệt.
                  </p>
                  <Button
                    icon={<Sparkles size={14} aria-hidden="true" />}
                    onClick={() => navigate(routes.tmsFlow.root)}
                  >
                    Mở tổng quan vận hành
                  </Button>
                </div>
              ) : (
                <div className="tms-stack">
                  {focusApprovals.map((approval) => (
                    <div
                      className="tms-agent-card"
                      key={approval.suggestion.decisionId}
                    >
                      <span className="tms-agent-card__kicker">
                        <Sparkles size={14} aria-hidden="true" /> Đề xuất · {approval.suggestion.rank == null ? "Chưa xếp hạng" : `Hạng #${approval.suggestion.rank}`} · {approval.suggestion.confidence ?? "Cần xác minh"}
                      </span>
                      <Tooltip
                        title={`${approval.suggestion.truckNumber ?? approval.suggestion.truckId}${approval.suggestion.score == null ? "" : ` · ${Number(approval.suggestion.score).toFixed(1)}`}`}
                      >
                        <h3 className="tms-agent-card__title table-cell-ellipsis">
                          {approval.suggestion.truckNumber ?? approval.suggestion.truckId}
                          {approval.suggestion.score == null
                            ? " · Chưa đủ dữ liệu đánh giá"
                            : ` · ${Number(approval.suggestion.score).toFixed(1)}`}
                        </h3>
                      </Tooltip>
                      <Tooltip title={approval.suggestion.reasoning}>
                        <p className="tms-agent-card__body">
                          {approval.suggestion.reasoning}
                        </p>
                      </Tooltip>
                      <div className="tms-row">
                        {decisionMetrics(approval).map((metric) => (
                          <span className="tms-kpi__hint" key={metric}>
                            {metric}
                          </span>
                        ))}
                      </div>
                      <div className="tms-agent-card__actions">
                        <Button
                          onClick={() => setReviewed(approval)}
                          type="primary"
                        >
                          Xem và quyết định
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </FlowPanel>
          )}

          {!approvalsOnly ? (
            <FlowPanel title="Dòng thời gian vận hành">
              {renderTimeline(5)}
            </FlowPanel>
          ) : null}

        </div>
      </div>

      {reviewed ? (
        <ApproveSuggestionModal
          approval={reviewed}
          key={reviewed.suggestion.decisionId}
          onClose={() => setReviewed(null)}
          onDecisionComplete={approvalsOnly ? undefined : handleDecisionComplete}
          onSuggestionChanged={(suggestion) => {
            setReviewed((current) => current ? { ...current, suggestion } : current);
          }}
          open
        />
      ) : null}
      {bulkReviewOpen ? (
        <ApproveSelectedSuggestionsModal
          approvals={selectedApprovals}
          onClose={() => {
            setBulkReviewOpen(false);
            setSelectedDecisionIds(new Set());
          }}
          open
        />
      ) : null}
    </div>
  );
}
